public interface  INFO {
    void info();
}

