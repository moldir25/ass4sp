public interface LibraryDecorator extends LibraryService {
}
