import java.util.List;
public class LibraryAdapter implements ExternalServiceAdapter {
    public List<Book> fetchBooksFromExternalService() {
        return null;
    }

    public Student fetchStudentInfoFromExternalService(int studentId) {
        return null;
    }
}
